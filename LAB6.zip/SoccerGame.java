package com;

public class SoccerGame {
//Declaring the instance variables ; 
	
	private String firstTeamName; 
	private String secondTeamName; 
	private int firstTeamScore, secondTeamScore; 
	private int firstTeamPenaltyScore; 
	private int secondTeamPenaltyScore; 
   private static int recordScore=10;
   
 
// 1st Constructor : used when the goalscore are equal
	
	public SoccerGame(String firstTeamName,String secondTeamName,int firstTeamScore,
			int secondTeamScore) 
	{
 //Assigning instance variables to local variables ; 		
			this.firstTeamName=firstTeamName;
			this.secondTeamName=secondTeamName;
			this.firstTeamScore=firstTeamScore; 
	        this.secondTeamScore=secondTeamScore;
	        
	//		* this.firstTeamPenaltyScore=firstTeamPenaltyScore;   * 
	//		* this.secondTeamPenaltyScore=secondTeamPenaltyScore; *
	
	//		assigning 0 to the scores if the score is 0 ; 
			
			if(firstTeamScore<0) {
				firstTeamScore=0; 
			}
			if(secondTeamScore<0) {
				secondTeamScore=0; 
			}
			if(firstTeamPenaltyScore<0) {
				firstTeamPenaltyScore=0;
			}
			if(secondTeamPenaltyScore<0) {
				secondTeamPenaltyScore=0; 
			}
	//	assigning recordScore if any of the score exceed the record score;  	
		  	
		if(firstTeamScore>this.recordScore) {
			recordScore=firstTeamScore; 
		}
		if(secondTeamScore>this.recordScore) {
			recordScore=secondTeamScore; 
		}
			
		
	}
	
 // 2nd Constructor ; 	
	public SoccerGame(String firstTeamName, String secondTeamNam, int firstTeamScore,
			int secondTeamScore, int firstTeamPenaltyScore, 
			int secondTeamPenaltyScore ) {
		this.firstTeamName=firstTeamName;
		this.secondTeamName=secondTeamName;
		this.firstTeamScore=firstTeamScore; 
        this.secondTeamScore=secondTeamScore;
        this.firstTeamPenaltyScore=firstTeamPenaltyScore;    
		this.secondTeamPenaltyScore=secondTeamPenaltyScore; 
		
	
//		assigning recordScore if any of the score exceed the record score;  	
	  	
			if(firstTeamScore>this.recordScore) {
				recordScore=firstTeamScore; 
			}
			if(secondTeamScore>this.recordScore) {
				recordScore=secondTeamScore; 
			}
				
	}
	
	// two getters
		
		public int getScore1() {
			return this.firstTeamScore;
		}
		public int getScore2() {
			return this.secondTeamScore;
		}
	//mutator setgoalScore
		public void setGoalScore(int teamScore1, int teamScore2) {
			this.firstTeamScore=teamScore1; 
			this.secondTeamScore=teamScore2; 
			
			if(firstTeamScore!=secondTeamScore){
				firstTeamPenaltyScore=0; 
				secondTeamPenaltyScore=0; 
			}
		}
	
		public void setGoalScore(int teamScore1, int teamScore2, int penaltyScore1, 
				                int penaltyScore2) {
			this.firstTeamPenaltyScore=penaltyScore1; 
			this.firstTeamScore=teamScore1; 
			this.secondTeamPenaltyScore=penaltyScore2; 
			this.secondTeamScore=teamScore2; 
		}
		
		public String winner() {
			String winner=null; 
			if(firstTeamScore>secondTeamScore) {
				winner=firstTeamName; 
			}
			else if(secondTeamScore>firstTeamScore) {
				winner=secondTeamName; 
			}
			else {
				if(firstTeamPenaltyScore>secondTeamPenaltyScore) {
					winner=firstTeamName; 
				}
				else if(secondTeamPenaltyScore>firstTeamPenaltyScore) {
				      	winner = secondTeamName; 
				}
			}
			
		return winner; 
		}
		
  public static int getHistoric() {
	return recordScore;   }

}

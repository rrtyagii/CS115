package com;

import java.util.Scanner;

public class Client {
	public static void main(String[] args) {
	SoccerGame game1 = new SoccerGame("Holland", "Brazil", 1, 2) ; 
	String winner1=game1.winner(); 
	SoccerGame game2=new SoccerGame("Ukraine", "Sweden", 1, 1, 3, 4); 
	String winner2=game2.winner(); 
	
	SoccerGame game3=new SoccerGame(winner1, winner2, 2, 3); 
	
	Scanner scan=new Scanner(System.in); 
	System.out.println("Please enter the score for team 1" ); 
     int score1=scan.nextInt(); 
     System.out.println("Please enter the score for team 2");
     int score2=scan.nextInt(); 
     
     if(score1!=score2) {
    	 game3.setGoalScore(score1, score2);
     }
     else {
    	 System.out.println("Now, please enter the penalty score for team 1");
    	 int penaltyScore1=scan.nextInt(); 
    	 System.out.println("Again, enter the penalty score for team 2");
    	 int penaltyScore2=scan.nextInt(); 
    	 game3.setGoalScore(score1, score1, penaltyScore1, penaltyScore2);
      }
     System.out.println("The winner of game 3 is "+game3.winner());
   }
}

//package com; 

public class MathFun {
   private int nbr; 
   private String name; 
   
   public MathFun(int nbr, String name) {
	   this.nbr=nbr; 
	   this.name=name; 
   }
   public int sumOdd() {
	   //int number=1;
	   int sum=0; 
	   for(int i=1;i<=nbr; i++ ) {
		   int oddNumber=( (2*i)-1);
		   sum+=oddNumber; 
	   }
	   return sum; 
	}
   
   public int allFactorial() {
	   int factorial=1; 
	   for(int i=1; i<=nbr; i++) {
		    factorial=factorial*i; 
	   }
	 //  System.out.println("the factorial of the number "+nbr+" is "+factorial);
	   return factorial;
   }
  // rethink this prime function;  
   public int nearPrime() {
	   for(int i=2; i<=nbr; i++) {
		   while(nbr%i==0)
			   nbr=nbr/i;
		}
	   if(nbr>1) {
		   
	   }
	   return nbr; 
	}
 //rethink the prime number function; 
   
//   public String reorderName() {
//	   
//	   for(int i=0; i<name.length(); i++) {
//		   
//	   }
//   }
//   
//   
   public String getName() {
	   return name; 
   }
   public void setName(String name) {
	   this.name=name; 
   }
   
}

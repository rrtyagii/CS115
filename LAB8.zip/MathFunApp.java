//package com;

public class MathFunApp {
  public static void main(String args[]) {
	  MathFun testing=new MathFun(6, "Rishabh"); 
	  
	  System.out.println(testing.sumOdd()); 
	  System.out.println(testing.allFactorial()); 
  }
}

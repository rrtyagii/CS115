package co;

public class CruiseControl {
     
	private boolean cruiseSet; 
	private int targetSpeed, currentSpeed; 
	
	public CruiseControl(int targetSpeed, int currentSpeed, boolean cruiseSet) {
			this.targetSpeed=targetSpeed; 
			this.currentSpeed=currentSpeed; 
			this.cruiseSet=cruiseSet; 
			
			if( (currentSpeed<=25) || (targetSpeed>100) ){
				this.cruiseSet=false; 
			    }
			else if(targetSpeed<0) {
				targetSpeed=0;
				this.cruiseSet=false; 
				
			    }
			else {
				this.cruiseSet=true; 
			    }
		
       	}
	// accessor
	
	public boolean getCruiseSet() {
		return this.cruiseSet; 
	}
	
	//mutator methods
	    // to set current speed
	public void setCurrentSpeed(int currentSpeed) {
		if(currentSpeed<0) {
			currentSpeed=0; 
		}
		this.currentSpeed=currentSpeed; 
	}
	    //to set cruiseSet
	public void setCruiseSet(boolean cruiseSet) {
		if(this.currentSpeed>25) {
			this.cruiseSet=cruiseSet;
		}
	 }
	
	//control acceleration method
	public boolean controlAcceleration() {
		if((cruiseSet==true) && (currentSpeed!=targetSpeed) ) {
			return true; 
		}
		else {
			return false; 
		}
	}
	
	//adjust acceleration method
	public void adjustAccelaration() {
		if(controlAcceleration()) {
			if(targetSpeed!=currentSpeed) {
				while(targetSpeed!=currentSpeed) {
						if(targetSpeed>currentSpeed) {
							currentSpeed++; 
						         }
						else {
							currentSpeed--; 
						     }
						
				        }
			      }        
		     }
	    }

	@Override   //NOt sure about this .. need to get it check
	public boolean equals(CruiseControl obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}
	
	
	
	
}



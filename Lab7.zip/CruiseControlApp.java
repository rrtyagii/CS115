package co;

public class CruiseControlApp {

	public static void main(String[] args) {
		CruiseControl cruise1=new CruiseControl(45, 20, false) ; 
		
		if(cruise1.controlAcceleration()) {
			cruise1.adjustAccelaration();
		}
		//
		else if(cruise1.getCruiseSet()==false) {
			System.out.println("the cruise control not set");
		}
		else {
			System.out.println("no adjustment made");
		}
		
	  CruiseControl cruise2=new CruiseControl(45,20, true); 
	   
	    boolean result=cruise2.equals(cruise1); 
	    System.out.println("Contents of two object is equal? if yes"
	    		+ " print true , if not print false. "+result);
	}
}

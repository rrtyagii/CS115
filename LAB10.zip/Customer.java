package cog;

public class Customer {
  private int accountNumber; 
  private double balance; 
  private String type; 
  
  private static int counter=0; 
  
  public Customer(int accountNumber, double balance, String type) {
	      counter++; 
	  this.accountNumber=counter;
	  
	  if(balance>0) {
		  this.balance=balance; 
	  }
	  
	  this.type=type; 
  }

	@Override
	public String toString() {
		return "Customer [accountNumber=" + this.accountNumber + ", balance=" + this.balance + ", type=" + this.type + "]";
	}
	
	
  
  
}

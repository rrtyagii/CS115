package cog;

import java.io.*;
import java.util.*;

public class CustomerMain {

	 static ArrayList<Customer> customer=new ArrayList<Customer>();
	 
	 public static void main (String[] args) throws FileNotFoundException {
		 File file = new File("customer.txt"); 
		 Scanner scan = new Scanner(file); 
		 
		 while(scan.hasNextLine()) {
			 String line= scan.nextLine(); 
			 String []tok=line.split(","); 
			 int number = Integer.parseInt(tok[0]); 
			 double body= Double.parseDouble(tok[1]); 
			 Customer custom=new Customer(number, body, tok[2]); 
			 customer.add(custom); 
		 }
		 
		 for(int i=0; i<customer.size(); i++) {
			 System.out.println(customer.get(i).toString());
		 }
		 
	 }
	 
}

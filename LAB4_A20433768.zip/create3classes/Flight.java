package create3classes;


public class Flight {
   private String flightNumber, airline, depCity, desCity ; 
   private double price; 
   
  public Flight() {
	flightNumber="XXXXX" ; 
	airline="XXXXXXXXX" ; 
	depCity="XXX" ; 
	desCity="XXX" ; 
	price=0000.000000; 
	
   }
  public Flight(String flightNumber, String airline, String depCity, 
		                 String desCity, double prices) 
  {
	  setFlightNumber(flightNumber); 
	  setairline(airline); 
	  setDepCity(depCity); 
	  setDesCity(desCity);
	  setprice(prices);
  }
   public void setFlightNumber(String flightNUmber) { //fli
     	flightNumber=flightNUmber ; 
   }
   
   public void setairline(String airLine) {
	   airline=airLine; 
   }
   
   public void setDepCity(String dePCity) {
	   depCity=dePCity; 
   }
public void setDesCity(String deSCity) {
	   desCity=deSCity; 
   }
   public void setprice(double prices) 
   {    price=prices ; 
   }
   
    public String getFlightNumber() {
    	return flightNumber;
    }
//    public String getAirline() {
//    	return airline;
//    }
    public String getDepCity() {
    	return depCity;
    }
//    public String getDesCity() {
//    	return desCity;
//    }
    public double getPrice() {
    	return price; 
    }
    
    public double pricing(int numberOfDays)
    {
    	price=price+(numberOfDays*20) ; 
    	return price;
    }
}


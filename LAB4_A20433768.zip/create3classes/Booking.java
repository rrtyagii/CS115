package create3classes;
import java.util.*;

public class Booking {
//   private String customer1="Rishabh Tyagi" ; 
//   private String customer2="Yiyang Li" ; 
//   private long phoneNumber=312_547_8025L; 
//   private float earnedMileage=(float) 123.45 ; 
      
  public static void main (String[] args) {
	  Customer customer1=new Customer("Rishabh Tyagi", 7737336519L, 125) ;
	  Customer customer2=new Customer("Yiyang Li", 8884556465L, 120) ;
	  
	  System.out.println("Enter the information for flight 1: ");
	  Scanner scan=new Scanner(System.in) ; 
	  System.out.println("Enter Flight number ");
	  String fNumber1=scan.next(); 
	  System.out.println("Enter the Airline");
	  String airLIne1=scan.next(); 
      System.out.println("Enter the Destination City");
      String dCity1=scan.next();
      System.out.println("Enter the Departure City") ; 
	  String dpCity1=scan.next();
	  System.out.println("Enter the Price"); 
	  double prices1=scan.nextDouble();
//	  scan.nextLine();	
	  
	  Flight flight1=new Flight(fNumber1, airLIne1, dCity1, dpCity1, prices1) ;
	  System.out.println("Enter the information of flight 2: ");
	     
	  System.out.println("Enter Flight number ");
	  String fNumber2=scan.next(); 
	  System.out.println("Enter the Airline");
	  String airLIne2=scan.next(); 
      System.out.println("Enter the Destination City");
      String dCity2=scan.next();
      System.out.println("Enter the Departure City") ; 
	  String dpCity2=scan.next();
	  System.out.println("Enter the Price"); 
	  double prices2=scan.nextDouble();

	  Flight flight2=new Flight(fNumber2, airLIne2, dCity2, dpCity2, prices2) ;
	  System.out.println("Details of customer 1 : "+customer1.getCustomerName()+" "+customer1.getEarnedMileage() ) ;
	  double cutomer1PriceAfterFlight2=flight2.getPrice();
	  double updatedMileage=customer1.updateMileage(cutomer1PriceAfterFlight2) ; 
	  
	  System.out.println("Details of flight 2 :"+flight2.getFlightNumber()+" "+flight2.getDepCity()+" "+flight2.getPrice() ); 
	  
	  System.out.println("The updated earned mileage is "+updatedMileage);
	  double updatedFlight1Info=flight1.pricing(20) ;
	  System.out.println("Upadated Details of flight 1 :"+flight1.getFlightNumber()+" "+flight1.getDepCity()+" "+flight1.getPrice() ); 
	  
	  
	  
	  
	  
	   
//	  Scanner scan=new Scanner(System.in) ;
     }


}

package create3classes;

public class Customer {
// question 1 
	private String customerName; 
	private long phoneNumber; 
	private double earnedMileage;
	//question 2 
 public Customer(String customerNameNew, long phoneNumberNew, float earnedMileageNew) {
	 customerName=customerNameNew;
	 earnedMileage=earnedMileageNew;
	 phoneNumber=phoneNumberNew;
	 
 }
    //question 3
    public void setCustomerName(String customerName) {
	    this.customerName=customerName; 
         }
    public void setEarnedMileage(double earnedMileage) {
    	this.earnedMileage= earnedMileage; }
    
    public String getCustomerName()
    {
        return customerName ; 
    }
    public double getEarnedMileage() 
    {
       return earnedMileage; 
    }
    
    //question 4
   public double updateMileage(double price) {
	   double mileage =  (price/1.3) ;
	  earnedMileage+=mileage;
	       return earnedMileage; 
     }
 

}

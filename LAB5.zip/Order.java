package com;
import java.util.*; 

/*

Create two customers with your name and partner name, customer1 and  customer2, 
customer2 should be assigned 20_000 point.  

Ask the user to enter a bill_amount for customer1 and invoke the method  updateRewards 
to updated customer1 rewards points based on the enter bill_amount.  

Ask the user to enter a bill amout (<200) for customer2 and invoke the method 
redeemRewards to allow customer2 to pay with his/her rewards points and print the 
remaining  points amount.  

Invoke the customerCount method to print how many different customers signed up  for the 
rewards program.   

Invoke the toString method to print customer 1 information

*/
public class Order {

public static void main(String[] args) {
	Scanner scan=new Scanner(System.in) ; 
	
	Customer customer1=new Customer("RISHABH","TYAGI",000) ; 
	Customer customer2=new Customer("YIYANG","LI",20_000) ; 
	
	System.out.println("Enter a bill amount for customer 1");
	double bill_amount=scan.nextDouble();	
	customer1.updateRewards(bill_amount);
	
	System.out.println("Enter a bill amount which is less than 200 for customer 2");
	double billAmount=scan.nextDouble()	;
	customer2.redeemRewards(billAmount) ; 
	
	System.out.println(customer2.getRewardPoints() );
    
   System.out.println("The number of customer signed up is "+Customer.customerCount() ); 
    
   System.out.println("The latest customer1 info is "+customer1.toString() ); 	
	
  }
}

package com;

/*Create a class Customer that allows: creating customer to signup for rewards program, 
* with the  following fields: first, last name, rewardID and points  
* Declare the instance variables of the Customer class. 
* 
* Write a constructor to define all instance variables EXCEPT FOR the rewardID attribute. 
* The rewardID is unique for each customer and cannot be the same for two different 
* customers.You will use a static counter variable, to assign rewardID.Each time you 
* construct a  Customer instance, you will increment counter.The rewardID of a customer 
* will be assigned  this value of this counter. All other instance variables will be 
* assigned using the parameters of  the constructor. Use the “this” operator to 
* reference instance variables.  
* 
* Create setters for both first and last name.  
* 
* Create a method updateRewards to update the point based on purchase, this  method 
* takes a purchase/bill amount and adds 1 point for each dollar spent to the rewardsID  
* 
* Create a method redeemRewards that allows the customers to use points to pay the bill 
* (customer gets a dollar for each 100 points). This method takes the bill amount as 
* parameter, once bill is payed update the customer’s reward points remaining.   
* 
* Create getter for reward points. 
* 
* Create a static method customerCount that returns how many customers signed up to the 
* rewards program.  
* 
* Create a toString() method that returns the information of the object as a String
*/
public class Customer {

	private String firstName, lastName; 
	private int rewardID, points;
	
	private static int counter=0; 
	
	public Customer(String firstName, String lastName, int points) {
		counter++; 
		this.firstName=firstName; 
		this.lastName=lastName; 
		this.points=points;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
    public void updateRewards(double bill) {
    	this.points+=bill; 
    }                                                                                                 //counter
    public void redeemRewards(double bill) {
      System.out.println("CHECKING HOW MANY POINTS YOU HAVE!");
    	if(this.points%100==0) {
    	   System.out.println("You have "+this.points+" points.");
    		bill+=(this.points/100) ; 
         }
      updateRewards(bill);
    }
    
    public int getRewardPoints() { //getter for which method what is rewardpoint 
    	return this.points ; 
    }
     
    public static int customerCount() {
    	return counter ; 
    }

	@Override
	public String toString() {
		return "Customer [firstName=" + firstName + ", lastName=" + lastName + ", points=" + points + "]";
	}
}
